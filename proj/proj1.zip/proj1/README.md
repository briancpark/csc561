# Project 1: Ray Casting

Press spacebar to see the light change position randomly as well as triangles rendered
