# Project 3: Rasterization

I became so clueless on how to use Javascript libraries. So I asked ChatGPT to write me a Python script, and surprised
my ass it did. Hold down `!` to see the canvas refresh to the creative part. Then see it rotate along the Y view if you
keep pressing `!`.