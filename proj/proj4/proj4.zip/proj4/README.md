# Project 4: Texture and Transparency

Most of the time was spending how the solution shell works. After that, only a few minor additions are needed to support texturing!

For extra credit, I implemented painter's algorithm to improve the rendering of the transparent objects.

There is some code copied from online resources, most notably [Using Textures in WebGL](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/Tutorial/Using_textures_in_WebGL)