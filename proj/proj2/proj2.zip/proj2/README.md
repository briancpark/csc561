# Project 2: WebGL Intro

Press spacebar to see the color change randomly. Press it again each time to get a unique color gradient!