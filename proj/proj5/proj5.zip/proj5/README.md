# Project 5: Frogger

The assignment is available to view publicly on my website! [www.briancpark.com](https://www.briancpark.com/csc561/proj/proj5/index.html)

Move arrows to move the frog. You can also use wasd and WASD to move the perspective of the game board. Some other things that are implemented on top of the required components are sound effects. Press B to enable the transparencies (it looks ugly because I hand made every attribute and forgot to change it). Press "!" to lock camera.